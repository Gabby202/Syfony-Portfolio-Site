- Run s.py
- Run c.py in another console
- in c.py, type username and try some of the following commands :)

list of commands: 
"hello" - recieve greeting  
"compliment me" - recieve compliment
"whoami" - remind you of your inputted name
"ping" - show response time of server
"time" - current local time
"bufferTotal" - ammount of messages in buffer
