
# Echo client program
import socket
import hashlib
import time
HOST = '127.0.0.1'    # The remote host
PORT = 50007          # The same port as used by the server



s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((HOST, PORT))
print "type username:"
username = raw_input()

print "type input:"
text = raw_input()


#if ping is in text start the timer
if "ping" in text:
	#start the timer
	startTime = time.time()
	print "ping start time "+str(startTime)
	# <cmd>message:hello there - dfdfdfdfs355654 </cmd>

hash = hashlib.sha224(text+'18').hexdigest()
output = '<cmd>message:'+username+':'+text+'-'+hash+'</cmd>' #holder for the command



# when we send data to the server, we are using a colon
# at the end of a sentence to mark the end of the current sentence
# later when the input comes back, we will then be breaking the input
# into individual parts using the colon : to separate the lines
if "ping" in text:
	output = '<cmd>ping</cmd>'

s.sendall(output + ";")

data = s.recv(80000)

# breaking apart the data we get back.
response = data.split(';')


for x in response:
	print str(x)

if "pong" in response:
	print "stop timer"
	stopTime = time.time()
	print "stop time " +str(stopTime)

	totalTime = stopTime - startTime
	print "Total time " +str(totalTime)

elif "bufferTotal" in response: 
	print total
	


s.close()